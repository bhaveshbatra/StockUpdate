package com.cts.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class IndexController {
	
	@RequestMapping("/adminRegister")
	public String display()
	{
		return "adminregister";
	}
	
	@RequestMapping("/")
	public String display1()
	{
		return "home";
	}
	
	@RequestMapping("/adminLogin")
	public String login()
	{
		return "adminlogin";
	}
	
	@RequestMapping("/userRegister")
	public String userreg()
	{
		return "userregister";
	}
	
	@RequestMapping("/userLogin")
	public String userlog()
	{
		return "userdashboard";
	}

}
