package com.cts.dao;

import java.util.List;

import com.cts.model.Admin;

public interface AdminDao {
	
	List<Admin> getAllAdmins();
	Admin getAdmin(int admin1);
	boolean AddCompany(Admin admin);
	
	 
	public List<Number> getAllId();
	

}
