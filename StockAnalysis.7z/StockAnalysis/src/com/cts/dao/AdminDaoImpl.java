package com.cts.dao;

import org.springframework.stereotype.Repository;

public class AdminDaoImpl {
	
	

}
