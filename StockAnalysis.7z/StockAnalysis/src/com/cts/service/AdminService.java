package com.cts.service;

public class AdminService {

}
